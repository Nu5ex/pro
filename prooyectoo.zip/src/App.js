import React, { useState } from "react";
import { BrowserRouter as Router, Route, Redirect, Switch } from "react-router-dom";
import "./styles.css";
import SignInForm from "./SignIn";
import SignUpForm from "./SignUp";
import Users from "./users";
import LOGOPROYECTO2 from './assets/LOGOPROYECTO2.png';

function App() {
  const [type, setType] = useState("signIn");

  const handleOnClick = (text) => {
    
  };

  const containerClass = "container " + (type === "signUp" ? "right-panel-active" : "");

  return (
    <Router>
      <div className="App">
        <img src={LOGOPROYECTO2} className='img1' alt="Logo"/>
        <div className={containerClass} id="container">
          <Switch>
            <Route path="/signIn" component={SignInForm} />
            <Route path="/signUp" component={SignUpForm} />
            <Route path="/users" component={Users} />
            <Redirect from="/" to="/signIn" />
          </Switch>
          <div className="overlay-container">
            <div className="overlay">
              <div className={`overlay-panel overlay-left ${type === "signUp" ? "hidden" : ""}`}>
                <h1>Hello, Friend!</h1>
                <p>Enter your personal details and start the journey with us</p>
                <button
                  className="ghost"
                  onClick={() => handleOnClick("signIn")}
                >
                  Sign In
                </button>
              </div>
              <div className={`overlay-panel overlay-right ${type === "signIn" ? "hidden" : ""}`}>
                <h1>Welcome Back!</h1>
                <p>To keep connected with us, please log in with your personal info</p>
                <button
                  className="ghost"
                  onClick={() => handleOnClick("signUp")}
                >
                  Sign Up
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
